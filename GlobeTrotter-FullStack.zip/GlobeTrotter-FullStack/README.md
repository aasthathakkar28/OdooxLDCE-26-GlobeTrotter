# GlobeTrotter - Full Stack Travel Planner

## Stack
- Client: React + Vite
- Server: Node.js + Express
- Database: JSON file database (zero MongoDB setup required)
- Authentication: JWT + bcrypt

## Run
```bash
npm install
npm run install:all
npm run dev
```

Client: Vite URL shown in terminal (normally localhost:5173)
Server: http://localhost:5000

Demo credentials are created automatically:
- Email: demo@globetrotter.com
- Password: demo123

## Structure
client/ = React frontend
server/ = Express API, authentication and persistent data
server/data/db.json = created automatically and stores users/trips
